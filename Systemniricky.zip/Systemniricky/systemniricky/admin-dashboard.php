<?php require 'connection.php';?>
<?php 

if(!isset($_SESSION['status'])){
    echo '<script>alert ("Please login first") ; window.location.href = "admin.php"; </script>';
    exit();
}

$username = $_SESSION['username'];

if(isset($_POST['logout'])){
	if(isset($_SESSION['username'])){
		$username=$_SESSION['username'];
		$sql = "UPDATE `admin` SET `status` = '0' WHERE `username` = '$username'";
		$result = mysqli_query($conn, $sql);

		header("Location:logoutadmin.php");
		exit();
	}
}


    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Admin BMI Records</title>
</head>
<body>
<div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                BMI Records
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_foodlibrary.php">
                                Food Library
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="settingsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Settings
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="settingsDropdown">
                            <li>
                                <form action="" method="POST">
                                    <button type="submit" name="logout" value="logout" class="dropdown-item btn btn-danger" onclick="return confirm('Are you sure you want to logout?')">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                    </ul>
                </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Admin Dashboard</h1>
                </div>
				<h2>BMI Records</h2>
<table border="1" class="table table-bordered text-center table-hover table-light border-dark">
		<th>Weight</th>
		<th>Height</th>
		<th>Overall BMI</th>
		<th>Action</th>
<?php
	        $sql = "SELECT * FROM bmi_users";
			$result = $conn->query($sql);

			if($result->num_rows > 0){
				while($row = $result -> fetch_assoc()){
			echo "<tr>";
			echo "<td>".$row["weight"]."</td>";
			echo "<td>".$row["height"]."</td>";
			echo "<td>".$row["bmi"]."</td>";
			echo "<td><a href='updatebmi.php?bmi_id=".$row["bmi_id"]."'  class='btn btn-info'>Edit</a> || <a href='deletebmi.php?bmi_id=".$row["bmi_id"]."'  class='btn btn-danger'>Delete</a></td>";
			echo "</tr>";
				}
			}else{
				echo "<tr><td colspan = '7'> No records found</td></tr>";
			}
?>
		</table>

		<br>
<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>