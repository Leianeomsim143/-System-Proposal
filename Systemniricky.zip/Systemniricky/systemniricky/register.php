<?php include 'connection.php' ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="bootstrap.css">
  <title>Register</title>
</head>

<body>
  <form action="" method="post" class="form-group text-center">
    <br><br>
    <div class="container">
    <h2>SIGN UP!</h2>
    <?php

if (isset($_POST['submit'])) {
  $users = $_POST['user'];
  $passs = $_POST['pass'];
  $lnames = $_POST['lname'];
  $fnames = $_POST['fname'];
  $mnames = $_POST['mname'];

  $query = "SELECT * FROM `tbl_users` WHERE `username` = '$users'";
  $stmts = $conn->prepare($query);
  $stmts->execute();
  $result = $stmts->get_result();
  $row = $result->fetch_assoc();

  if ($users == @$row['username']) {

    echo '<p class="text-danger">User already exist! Please try another username!</p>';
  } else {

    $sql = "INSERT INTO `tbl_users`( `username`, `password`, `lastname`, `firstname`, `middlename`) VALUES (?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $users, $passs, $lnames, $fnames, $mnames);
    $stmt->execute();
    echo '<script>alert ("Register Successfully!") ; window.location.href = "index.php"; </script>';
  }
}
?>
    <label for="user">Username: <span class="required-indicator">
        <input type="text" name="user" id="user" placeholder="Username" required><br><br>

        <label for="pass">Password: <span class="required-indicator">
            <input type="password" name="pass" id="pass" placeholder="Password" required><br><br>

            <label for="fname">Firstname: <span class="required-indicator">
                <input type="text" name="fname" id="fname" placeholder="Firstname" required><br><br>

                <label for="mname">Midname: <span class="required-indicator">
                    <input type="text" name="mname" id="mname" placeholder="Midname" required><br><br>

                    <label for="lname">Lastname: <span class="required-indicator">
                        <input type="text" name="lname" id="lname" placeholder="Lastname" required><br><br>

                        <input type="checkbox" onclick="myFunction()"> Show Password<br><br>

                        <button type="submit" name="submit" class="btn btn-success">REGISTER</button><br><br>
                        <p>Already have an account? <a href="index.php" class="btn btn-outline-info">Login Here</a></p>
                        </div>
  </form>

  <script>
    function myFunction() {
      var x = document.getElementById("pass");
      if (x.type === "password") {
        x.type = "text";
      } else {
        x.type = "password";
      }
    }
  </script>

</body>
</html>

<style>
  .container{
    border: none;
    background: whitesmoke;
    padding: 1cm;
    border-radius: 5px;
    transition: 1s;
    width: 30svw;
  }

  .container:hover{
    box-shadow: 1px 5px 5px 5px;
  }
</style>