<?php require 'connection.php';

if (!isset($_SESSION['status'])) {
    echo '<script>alert ("Please login first") ; window.location.href = "index.php"; </script>';
    exit();
}

$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];


if (isset($_POST['logout'])) {
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
        $sql = "UPDATE `tbl_users` SET `Status` = '0' WHERE `Username` = '$username'";
        $result = mysqli_query($conn, $sql);

        header("Location:logout.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Client Dashboard</title>
</head>

<body>
    <form action="" method="post" class="form-control text-center">
        <h1>Enter your BMI</h1>
        <label for="kilo">Weight (Kilogram): </label>
        <input type="float" name="weight"><br><br>
        <label for="cm">Height (Centimeter): </label>
        <input type="float" name="height"><br><br>
        <button type="submit" name="submit" class="btn btn-outline-success">Submit</button>
        <br><br><br>

        <?php
        $showTable = false;

        if (isset($_POST['submit'])) {
            $weight = $_POST['weight'];
            $height = $_POST['height'];

            if (empty($weight) || empty($height)) {
                echo '<p class="text-danger" >Please enter weight and height.</p>';
            } else {
                $sql = "SELECT * FROM `bmi_users` WHERE `weight` = ? AND `height` = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $weight, $height);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
            }
            $height = $height / 100;
            $division = $weight / ($height * $height);
            $format = number_format($division, 2);


            $sql = "INSERT INTO `bmi_users`( `weight`, `height`, `bmi`, `user_id`) VALUES (?,?,?,?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $weight, $height, $format, $user_id);
            $stmt->execute();

            $_SESSION['bmi'] = $format;

        }
        ?>
    </form>




<?php
//If else bmi classification
            if (isset($_SESSION['bmi'])) {
                echo "<br>" . "<br>" . 'Your BMI is ' . $_SESSION['bmi'] . "<br>";
                echo "<table class='table-striped table-hover table-bordered table-primary align-middle text-center>'";
                echo "<tr style='text-align: center'>";
                echo '<th class="text-nowrap px-2">Food Name</th>';
                echo '<th class="text-nowrap px-2" style="width: 30%;">Food Findings</th>';
                echo '<th class="text-nowrap px-2">Food Calories</th>';
                echo '<th class="text-nowrap px-2">Food Carbohydrates</th>';
                echo '<th class="px-2">Exercises</th>';
                echo '<th class="px-2" style="width: 30%; text-align: center;">Food Picture</th>';
                echo '</tr>';
                if ($_SESSION['bmi'] < 18.5) {
                    $sql = "SELECT * FROM recommend WHERE reco_id = 1";
                    $result = $conn->query($sql);
                    $reco_id = 1;
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='text-align: justify;'>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["food_name"] . "</td>";
                            echo "<td style='padding: 2svw;'>" . $row["food_desc"] . "</td>";
                            echo "<td style='padding: 0 2svw;' >" . $row["food_calories"] . "</td>";
                            echo "<td style='padding: 0 2svw;'>" . $row["food_carbohydrates"] . "</td>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["exercise"] . "</td>";
                            echo "<td><img class='d-block mx-auto' src='data:image/jpeg;base64," . base64_encode($row["food_picture"]) . "' width='200' '></td>";
                            echo "</tr>";
                        }
                    }
                    echo "You're Underweight. Please proceed to food library to customize or build your own fitness plan!";
                } elseif ($_SESSION['bmi'] >= 18.5 && $_SESSION['bmi'] <= 24.9) {
                    $sql = "SELECT * FROM recommend WHERE reco_id = 2";
                    $result = $conn->query($sql);
                    $reco_id = 2;
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='text-align: justify;'>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["food_name"] . "</td>";
                            echo "<td style='padding: 2svw;'>" . $row["food_desc"] . "</td>";
                            echo "<td style='padding: 0 2svw;' >" . $row["food_calories"] . "</td>";
                            echo "<td style='padding: 0 2svw;'>" . $row["food_carbohydrates"] . "</td>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["exercise"] . "</td>";
                            echo "<td><img class='d-block mx-auto' src='data:image/jpeg;base64," . base64_encode($row["food_picture"]) . "' width='200' '></td>";
                            echo "</tr>";
                        }
                    }
                    echo "You're Normal. Please proceed to food library to customize or build your own fitness plan! ";
                } elseif ($_SESSION['bmi'] >= 25 && $_SESSION['bmi'] <= 29.9) {
                    $sql = "SELECT * FROM recommend WHERE reco_id = 3";
                    $result = $conn->query($sql);
                    $reco_id = 3;
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='text-align: justify;'>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["food_name"] . "</td>";
                            echo "<td style='padding: 2svw;'>" . $row["food_desc"] . "</td>";
                            echo "<td style='padding: 0 2svw;' >" . $row["food_calories"] . "</td>";
                            echo "<td style='padding: 0 2svw;'>" . $row["food_carbohydrates"] . "</td>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["exercise"] . "</td>";
                            echo "<td><img class='d-block mx-auto' src='data:image/jpeg;base64," . base64_encode($row["food_picture"]) . "' width='200' '></td>";
                            echo "</tr>";
                        }
                    }
                    echo "You're Overweight. Please proceed to food library to customize or build your own fitness plan!";
                } elseif ($_SESSION['bmi'] >= 30) {
                    $sql = "SELECT * FROM recommend WHERE reco_id = 4";
                    $result = $conn->query($sql);
                    $reco_id = 4;
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='text-align: justify;'>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["food_name"] . "</td>";
                            echo "<td style='padding: 2svw;'>" . $row["food_desc"] . "</td>";
                            echo "<td style='padding: 0 2svw;' >" . $row["food_calories"] . "</td>";
                            echo "<td style='padding: 0 2svw;'>" . $row["food_carbohydrates"] . "</td>";
                            echo "<td style='padding: 0 2svw; min-width: 200px'>" . $row["exercise"] . "</td>";
                            echo "<td><img class='d-block mx-auto' src='data:image/jpeg;base64," . base64_encode($row["food_picture"]) . "' width='200' '></td>";
                            echo "</tr>";
                        }
                    }
                    echo "You're Obese. Please proceed to food library to customize or build your own fitness plan!";
                } else {
                    echo "Invalid input"; // Add this in case $format is not a valid number
                }

                echo "<br><br>"."<a href='customize.php?reco_id=" . $reco_id . "'  class='btn btn-info mx-2'>Customize It! </a> <a href='foodlibrary.php'class='btn btn-info'>Food Library</a>". "<br><br>";

            }
            echo '</table>';
        
?>

<br>

<form action="" method="POST">
    <button type="submit" name="logout" value="logout" class="btn btn-danger" onclick="return confirm('Are you sure you want to logout?')">Logout</button><br><br>
</form>
</body>

</html>