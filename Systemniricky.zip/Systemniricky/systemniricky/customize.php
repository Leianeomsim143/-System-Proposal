<?php include 'connection.php' ;?>
<?php 

if(!isset($_SESSION['status'])){
    echo '<script>alert ("Please login first") ; window.location.href = "index.php"; </script>';
    exit();
}

$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];

    ?>
<?php
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $reco_id = $_POST['reco_id'];
        $food_name = $_POST['food_name'];
        $food_desc = $_POST['food_desc'];
        $food_calories = $_POST['food_calories'];
        $food_carbohydrates = $_POST['food_carbohydrates'];
        $exercise = $_POST['exercise'];
    
            $sql = "UPDATE recommend SET food_name ='$food_name', food_desc='$food_desc', food_calories = '$food_calories', food_carbohydrates='$food_carbohydrates', exercise = '$exercise' WHERE reco_id='$reco_id'";

        $conn->query($sql);
        header("Location: dashboard.php");
        exit();
    }

    $reco_id = isset($_GET['reco_id']) ? $_GET['reco_id'] : null;
    if(!$reco_id){
        die('Invalid ID');
    }

    $sql = "SELECT * FROM recommend WHERE reco_id=$reco_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.css">
    <title>Update Food Library</title>
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data" class="form-group text-center">
    <h2>Customize Fitness Plan</h2>
        <input type="hidden" name="reco_id" value="<?php echo $row['reco_id'];?>">
        <label for="">Food Name:</label>
        <textarea type="text" name="food_name"  id="exampleFormControlTextarea1" style="width: 30%;" value="<?php echo $row['food_name'];?>" required><?php echo htmlspecialchars($row['food_name']); ?></textarea><br><br>

        <label for="">Food Desc:</label>
        <textarea type="text" name="food_desc" style="width: 30%;" value="<?php echo $row['food_desc'];?>"><?php echo htmlspecialchars($row['food_desc']); ?></textarea><br><br>

        <label for="">Food Calories:</label>
        <input type="text" name="food_calories" value="<?php echo $row['food_calories'];?>"><br><br>

        <label for="">Food Carbohydrates:</label>
        <input type="text" name="food_carbohydrates" value="<?php echo $row['food_carbohydrates'];?>"><br><br>

        <label for="">Exercise:</label>
        <textarea type="text" name="exercise" style="width: 30%;" value="<?php echo $row['exercise'];?>"><?php echo htmlspecialchars($row['food_desc']); ?></textarea><br><br>

        <input type="submit" value="Update Food" class="btn btn-success">
    </form>
    <br>
    <a href="dashboard.php" class="btn btn-danger" >Back</a>
</body>
</html>